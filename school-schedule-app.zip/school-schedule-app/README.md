# School Schedule App 🗓️

A full-stack timetable app. Students pick a **course** (1st, 2nd, 3rd year...)
and a **group** (A, B, C...), and the app shows their weekly class schedule,
Monday through Saturday.

- **Frontend:** Vite + React (functional components & hooks), Axios, plain CSS
- **Backend:** Node.js + Express, CORS enabled, data stored in a local JSON file (no database)

```
school-schedule-app/
├── backend/                 # Express API
│   ├── data/
│   │   └── schedules.json   # the "database" - all courses/groups/timetables
│   ├── server.js            # API routes (GET /schedule, GET /options)
│   └── package.json
│
└── frontend/                 # Vite + React app
    ├── index.html
    ├── src/
    │   ├── api/scheduleApi.js     # axios calls to the backend
    │   ├── components/            # Header, SelectorForm, ScheduleGrid, etc.
    │   ├── hooks/useLocalStorage.js
    │   ├── constants.js           # day order + time slots
    │   ├── utils.js
    │   ├── App.jsx                # main app logic / state
    │   ├── main.jsx                # React entry point
    │   └── index.css              # all styling (design tokens + components)
    └── package.json
```

## 1. Requirements

- [Node.js](https://nodejs.org/) version 18 or newer (includes npm)

## 2. Run the backend

Open a terminal:

```bash
cd backend
npm install
npm run start
```

You should see:

```
✅ School Schedule API running at http://localhost:5000
```

Leave this terminal running. Try it in your browser: `http://localhost:5000/schedule?course=1&group=A`

> Tip: `npm run dev` uses `nodemon` instead, which restarts the server automatically when you edit `server.js`.

## 3. Run the frontend

Open a **second** terminal (keep the backend running in the first one):

```bash
cd frontend
npm install
npm run dev
```

Vite will print a local URL, usually `http://localhost:5173`. Open it in your
browser - it should open automatically.

That's it! Pick a course and a group, click **Show Schedule**, and the weekly
timetable appears.

## 4. How the data flows

1. When the page loads, the frontend calls `GET /options` to find out which
   courses and groups exist, and uses that to fill in the two dropdowns.
2. When you click **Show Schedule**, the frontend calls
   `GET /schedule?course=<course>&group=<group>`.
3. The backend looks up that combination inside `backend/data/schedules.json`
   and returns it as JSON, e.g.:

   ```json
   {
     "course": "1",
     "group": "A",
     "schedule": {
       "monday": ["Math", "Physics", "English", "History", "PE", "Informatics"],
       "tuesday": ["Biology", "Chemistry", "Math", "Geography", "English", "Art"],
       "wednesday": ["..."],
       "thursday": ["..."],
       "friday": ["..."],
       "saturday": ["Optional classes"]
     }
   }
   ```
4. The frontend renders one card per weekday, pairing each subject with a
   fixed time slot (see `TIME_SLOTS` in `src/constants.js`).

## 5. Adding or editing schedules

No database, no migrations - just edit `backend/data/schedules.json`.

The file is structured as `course -> group -> day -> list of subjects`:

```json
{
  "1": {
    "A": { "monday": ["Math", "Physics"], "tuesday": ["..."] },
    "B": { "...": "..." }
  },
  "2": {
    "A": { "...": "..." }
  }
}
```

To add a 4th course, or a new group "D", just add a new key following the
same shape and save the file - the backend reads it fresh on every request,
and the frontend's dropdowns will pick up the new options automatically next
time the page loads.

Each day's subject list lines up with `TIME_SLOTS` in
`frontend/src/constants.js` by position (subject #1 = first time slot, etc).
Edit that array if your school's actual class times are different.

## 6. Features included

- Dependent dropdowns: groups update based on the selected course
- "Show Schedule" button with a loading state
- Animated, staggered fade-in for each day card
- Skeleton loading placeholders while the request is in flight
- Friendly empty/error/"no schedule found" states with a retry button
- Selected course/group (and light/dark theme) saved to `localStorage`,
  so your last choice is remembered next time you open the app
- "Today" badge on whichever weekday card matches the real current day
- Fully responsive layout (mobile and desktop) and a light/dark mode toggle

## 7. Customizing the look

All colors, fonts, spacing, and shadows are defined as CSS variables near the
top of `frontend/src/index.css`:

```css
:root {
  --color-bg: #ffffff;
  --color-text: #111111;
  --color-accent: #ff7a00; /* change this to re-theme the whole app */
  ...
}
```

Dark mode simply redefines the same variables under `[data-theme="dark"]`.

## 8. Troubleshooting

- **"Couldn't load courses from the server"** in the browser → the backend
  isn't running, or it's running on a different port. Check the first
  terminal, and make sure `frontend/.env` (`VITE_API_URL`) matches it.
- **CORS error in the browser console** → make sure `backend/server.js` is
  running the version with `app.use(cors())` (it is, by default).
- **Port already in use** → set a different port: `PORT=5001 npm run start`
  in `backend`, and update `VITE_API_URL` in `frontend/.env` to match.
