/**
 * constants.js
 * -----------------------------------------------------------------------
 * Small shared values used by more than one component, kept in one place
 * so they're easy to find and change.
 * -----------------------------------------------------------------------
 */

// The order days should appear in, and the key each one has inside the
// `schedule` object returned by the API (lowercase, matches schedules.json).
export const DAYS = [
  { key: "monday", label: "Monday" },
  { key: "tuesday", label: "Tuesday" },
  { key: "wednesday", label: "Wednesday" },
  { key: "thursday", label: "Thursday" },
  { key: "friday", label: "Friday" },
  { key: "saturday", label: "Saturday" },
];

// Fixed lesson times, applied in order to whatever subjects are listed
// for a given day (subject #1 happens in slot #1, and so on). Saturdays
// usually only have one or two subjects, so they simply use the first
// slot(s) and ignore the rest.
export const TIME_SLOTS = [
  "08:30 - 09:15",
  "09:25 - 10:10",
  "10:20 - 11:05",
  "11:15 - 12:00",
  "12:10 - 12:55",
  "13:05 - 13:50",
];

// JavaScript's Date.getDay() returns 0 (Sunday) through 6 (Saturday).
// This maps that number to our lowercase day keys, used to highlight
// "today" on the schedule. Sunday has no entry since the school week
// in this app runs Monday - Saturday.
export const WEEKDAY_INDEX_TO_KEY = {
  1: "monday",
  2: "tuesday",
  3: "wednesday",
  4: "thursday",
  5: "friday",
  6: "saturday",
};
