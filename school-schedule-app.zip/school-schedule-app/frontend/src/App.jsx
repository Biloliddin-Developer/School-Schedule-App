import { useEffect, useState, useCallback } from "react";
import Header from "./components/Header.jsx";
import SelectorForm from "./components/SelectorForm.jsx";
import ScheduleGrid from "./components/ScheduleGrid.jsx";
import SkeletonLoader from "./components/SkeletonLoader.jsx";
import StatePanel from "./components/StatePanel.jsx";
import { useLocalStorage } from "./hooks/useLocalStorage.js";
import { fetchOptions, fetchSchedule } from "./api/scheduleApi.js";

/**
 * App.jsx
 * -----------------------------------------------------------------------
 * The top-level component. It owns all of the app's state and decides
 * which "view" to render in the results area:
 *
 *   "idle"     -> nothing searched yet, show a friendly prompt
 *   "loading"  -> request in flight, show the skeleton loader
 *   "success"  -> got a schedule back, show the weekly grid
 *   "notfound" -> request succeeded but no schedule exists for that pick
 *   "error"    -> the request failed (network/server problem)
 *
 * Course, group, and theme are all persisted to localStorage via
 * useLocalStorage, so refreshing the page (or coming back tomorrow)
 * remembers what you last picked.
 * -----------------------------------------------------------------------
 */
export default function App() {
  // ---- Theme (light/dark) -------------------------------------------
  const [theme, setTheme] = useLocalStorage("schedule:theme", "light");

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  function toggleTheme() {
    setTheme((prev) => (prev === "dark" ? "light" : "dark"));
  }

  // ---- Dropdown options (courses + groups), loaded from the API -----
  const [courses, setCourses] = useState([]);
  const [groupsByCourse, setGroupsByCourse] = useState({});
  const [optionsLoading, setOptionsLoading] = useState(true);
  const [optionsError, setOptionsError] = useState("");

  const loadOptions = useCallback(async () => {
    setOptionsLoading(true);
    setOptionsError("");
    try {
      const data = await fetchOptions();
      setCourses(data.courses || []);
      setGroupsByCourse(data.groupsByCourse || {});
    } catch (err) {
      setOptionsError(
        "Couldn't load courses from the server. Make sure the backend is running on " +
          (import.meta.env.VITE_API_URL || "http://localhost:5000") +
          "."
      );
    } finally {
      setOptionsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadOptions();
  }, [loadOptions]);

  // ---- User's selection, remembered between visits -------------------
  const [course, setCourse] = useLocalStorage("schedule:course", "");
  const [group, setGroup] = useLocalStorage("schedule:group", "");

  // ---- Schedule search state ------------------------------------------
  const [status, setStatus] = useState("idle"); // idle | loading | success | notfound | error
  const [schedule, setSchedule] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");

  const handleSearch = useCallback(async () => {
    if (!course || !group) return;

    setStatus("loading");
    try {
      const data = await fetchSchedule(course, group);
      setSchedule(data.schedule);
      setStatus("success");
    } catch (err) {
      if (err.response?.status === 404) {
        setStatus("notfound");
      } else {
        setErrorMessage(
          err.response?.data?.error ||
            "Something went wrong while fetching the schedule. Please try again."
        );
        setStatus("error");
      }
    }
  }, [course, group]);

  // Once the dropdown options have loaded, if a course + group were
  // already remembered from a previous visit (and are still valid),
  // automatically show that schedule again instead of making the
  // person click "Show Schedule" every time they open the app.
  useEffect(() => {
    if (optionsLoading) return;
    const isStillValid = course && group && groupsByCourse[course]?.includes(group);
    if (isStillValid) {
      handleSearch();
    }
    // We intentionally only want this to run once, right after options
    // finish loading - not every time handleSearch/course/group change.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [optionsLoading]);

  return (
    <div className="app">
      <div className="app-container">
        <Header theme={theme} onToggleTheme={toggleTheme} />

        <section className="hero">
          <h2>
            Your week, <span className="accent">organized</span>.
          </h2>
          <p>Pick your course and group below to see all your classes, Monday through Saturday.</p>
        </section>

        <SelectorForm
          courses={courses}
          groupsByCourse={groupsByCourse}
          course={course}
          group={group}
          onCourseChange={setCourse}
          onGroupChange={setGroup}
          onSubmit={handleSearch}
          loading={status === "loading"}
          optionsLoading={optionsLoading}
        />

        {optionsError && (
          <div style={{ marginTop: 16 }}>
            <StatePanel icon="⚠️" title="Connection problem" message={optionsError} isError onRetry={loadOptions} />
          </div>
        )}

        <div className="results-area">
          {status === "loading" && <SkeletonLoader />}

          {status === "idle" && !optionsError && (
            <StatePanel
              icon="🗓️"
              title="No schedule selected yet"
              message="Choose a course and a group, then press “Show Schedule” to see your week."
            />
          )}

          {status === "success" && schedule && (
            <ScheduleGrid schedule={schedule} course={course} group={group} />
          )}

          {status === "notfound" && (
            <StatePanel
              icon="🔍"
              title="No schedule found"
              message={`We couldn't find a timetable for course "${course}", group "${group}". Try a different combination.`}
            />
          )}

          {status === "error" && (
            <StatePanel icon="⚠️" title="Something went wrong" message={errorMessage} isError onRetry={handleSearch} />
          )}
        </div>

        <footer className="app-footer">Built with Vite, React &amp; Express · School Schedule App</footer>
      </div>
    </div>
  );
}
