/**
 * utils.js
 * Tiny formatting helpers shared by more than one component.
 */

// Turns "1" into "1st", "2" into "2nd", "3" into "3rd", "11" into "11th", etc.
export function ordinal(value) {
  const n = Number(value);
  if (Number.isNaN(n)) return value;
  const lastTwo = n % 100;
  const lastDigit = n % 10;
  if (lastTwo >= 11 && lastTwo <= 13) return `${n}th`;
  if (lastDigit === 1) return `${n}st`;
  if (lastDigit === 2) return `${n}nd`;
  if (lastDigit === 3) return `${n}rd`;
  return `${n}th`;
}
