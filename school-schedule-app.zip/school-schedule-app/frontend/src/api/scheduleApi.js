/**
 * api/scheduleApi.js
 * -----------------------------------------------------------------------
 * Small wrapper around axios so the rest of the app never has to know
 * the exact URL or query-string shape of the backend endpoints.
 *
 * VITE_API_URL comes from the .env file in the frontend folder. Vite only
 * exposes env variables that start with "VITE_" to the browser, and you
 * access them through `import.meta.env` (not `process.env`, that's a
 * Node.js thing).
 * -----------------------------------------------------------------------
 */

import axios from "axios";

const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

const client = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
});

/**
 * Fetches the list of available courses and, for each course, the list
 * of groups inside it. Used to populate the two dropdowns dynamically.
 * Expected shape: { courses: ["1","2","3"], groupsByCourse: { "1": ["A","B"] } }
 */
export async function fetchOptions() {
  const response = await client.get("/options");
  return response.data;
}

/**
 * Fetches the weekly timetable for one course + group combination.
 * Expected shape: { course, group, schedule: { monday: [...], ... } }
 */
export async function fetchSchedule(course, group) {
  const response = await client.get("/schedule", {
    params: { course, group },
  });
  return response.data;
}
