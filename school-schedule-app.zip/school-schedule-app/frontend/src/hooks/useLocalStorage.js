import { useState, useEffect } from "react";

/**
 * useLocalStorage
 * -----------------------------------------------------------------------
 * Works exactly like React's useState, but the value is also saved to
 * (and restored from) the browser's localStorage under `key`.
 *
 * Example:
 *   const [course, setCourse] = useLocalStorage("schedule:course", "");
 *
 * The first time the component mounts, it tries to read an existing
 * value from localStorage; if there isn't one, it falls back to
 * `initialValue`. Every time `value` changes afterwards, it's written
 * back to localStorage automatically.
 * -----------------------------------------------------------------------
 */
export function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    try {
      const stored = window.localStorage.getItem(key);
      return stored !== null ? JSON.parse(stored) : initialValue;
    } catch {
      // If localStorage is unavailable (e.g. private browsing) or the
      // stored value isn't valid JSON, just fall back gracefully.
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // Ignore write errors (e.g. storage quota exceeded or disabled).
    }
  }, [key, value]);

  return [value, setValue];
}
