/**
 * StatePanel.jsx
 * -----------------------------------------------------------------------
 * One reusable component for every "there's nothing to show yet" moment:
 *  - idle:  user hasn't searched yet
 *  - empty: search succeeded but no schedule exists for that combination
 *  - error: the request failed (network issue, server error, etc.)
 *
 * Keeping these three in one component avoids repeating the same markup
 * three times across the app.
 * -----------------------------------------------------------------------
 */
export default function StatePanel({ icon, title, message, isError = false, onRetry }) {
  return (
    <div className={`state-panel ${isError ? "is-error" : ""}`}>
      <span className="state-icon" aria-hidden="true">
        {icon}
      </span>
      <h3>{title}</h3>
      <p>{message}</p>
      {onRetry && (
        <button type="button" className="btn-secondary" style={{ marginTop: 16 }} onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  );
}
