import ThemeToggle from "./ThemeToggle.jsx";

/**
 * Header.jsx
 * -----------------------------------------------------------------------
 * Top bar: app logo + name on the left, dark mode switch on the right.
 * -----------------------------------------------------------------------
 */
export default function Header({ theme, onToggleTheme }) {
  return (
    <header className="app-header">
      <div className="brand">
        <div className="brand-mark">S</div>
        <div className="brand-text">
          <h1>School Schedule</h1>
          <p>Your weekly classes, at a glance</p>
        </div>
      </div>
      <ThemeToggle theme={theme} onToggle={onToggleTheme} />
    </header>
  );
}
