/**
 * SkeletonLoader.jsx
 * -----------------------------------------------------------------------
 * Shown instead of the real schedule while the API request is in
 * flight. It mimics the shape of the final day cards (header + a few
 * lines) with a soft shimmering animation, so the layout doesn't jump
 * around once the real data arrives.
 * -----------------------------------------------------------------------
 */
export default function SkeletonLoader() {
  // Render 6 placeholder cards, one per weekday.
  const placeholders = Array.from({ length: 6 });

  return (
    <div className="schedule-grid" aria-busy="true" aria-label="Loading schedule">
      {placeholders.map((_, i) => (
        <div className="skeleton-card" key={i}>
          <div className="skeleton-header" />
          <div className="skeleton-line" style={{ width: "70%" }} />
          <div className="skeleton-line" style={{ width: "85%" }} />
          <div className="skeleton-line" style={{ width: "60%" }} />
        </div>
      ))}
    </div>
  );
}
