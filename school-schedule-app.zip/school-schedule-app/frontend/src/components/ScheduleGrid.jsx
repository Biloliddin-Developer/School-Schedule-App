import DayCard from "./DayCard.jsx";
import { DAYS, WEEKDAY_INDEX_TO_KEY } from "../constants.js";
import { ordinal } from "../utils.js";

/**
 * ScheduleGrid.jsx
 * -----------------------------------------------------------------------
 * Lays out one DayCard per weekday (Monday - Saturday) for the schedule
 * object returned by the API, e.g.:
 *   { monday: ["Math", "Physics"], tuesday: [...], ... }
 * -----------------------------------------------------------------------
 */
export default function ScheduleGrid({ schedule, course, group }) {
  const todayKey = WEEKDAY_INDEX_TO_KEY[new Date().getDay()];

  return (
    <>
      <div className="schedule-meta">
        <h3>Weekly timetable</h3>
        <span className="pill">
          {ordinal(course)} year · Group {group}
        </span>
      </div>

      <div className="schedule-grid">
        {DAYS.map(({ key, label }, index) => (
          <DayCard
            key={key}
            label={label}
            subjects={schedule[key]}
            isToday={key === todayKey}
            index={index}
          />
        ))}
      </div>
    </>
  );
}
