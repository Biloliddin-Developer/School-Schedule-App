/**
 * SelectorForm.jsx
 * -----------------------------------------------------------------------
 * The card with the "Course" dropdown, the "Group" dropdown, and the
 * "Show Schedule" button.
 *
 * The group dropdown depends on the chosen course - each course can have
 * a different set of groups, so we look that up from `groupsByCourse`
 * (which comes from the backend's GET /options endpoint).
 *
 * This component doesn't fetch anything itself or hold the "result" of
 * the search - it only reports the user's choices upward via props
 * (`onCourseChange`, `onGroupChange`, `onSubmit`). That keeps it simple
 * and easy to reuse/test on its own.
 * -----------------------------------------------------------------------
 */
import { ordinal } from "../utils.js";

export default function SelectorForm({
  courses,
  groupsByCourse,
  course,
  group,
  onCourseChange,
  onGroupChange,
  onSubmit,
  loading,
  optionsLoading,
}) {
  const availableGroups = course ? groupsByCourse[course] || [] : [];
  const canSubmit = Boolean(course && group) && !loading;

  function handleCourseChange(e) {
    const nextCourse = e.target.value;
    onCourseChange(nextCourse);

    // If the previously selected group doesn't exist for the new course,
    // clear it so the user doesn't submit an invalid combination.
    const stillValid = groupsByCourse[nextCourse]?.includes(group);
    if (!stillValid) {
      onGroupChange("");
    }
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (canSubmit) onSubmit();
  }

  return (
    <form className="selector-card" onSubmit={handleSubmit}>
      <div className="field">
        <label htmlFor="course-select">Course</label>
        <select
          id="course-select"
          value={course}
          onChange={handleCourseChange}
          disabled={optionsLoading}
        >
          <option value="">{optionsLoading ? "Loading..." : "Select a course"}</option>
          {courses.map((c) => (
            <option key={c} value={c}>
              {ordinal(c)} year
            </option>
          ))}
        </select>
      </div>

      <div className="field">
        <label htmlFor="group-select">Group</label>
        <select
          id="group-select"
          value={group}
          onChange={(e) => onGroupChange(e.target.value)}
          disabled={optionsLoading || !course}
        >
          <option value="">{course ? "Select a group" : "Pick a course first"}</option>
          {availableGroups.map((g) => (
            <option key={g} value={g}>
              Group {g}
            </option>
          ))}
        </select>
      </div>

      <button type="submit" className="btn-primary" disabled={!canSubmit}>
        {loading ? "Loading..." : "Show Schedule"}
      </button>
    </form>
  );
}
