import { TIME_SLOTS } from "../constants.js";

/**
 * DayCard.jsx
 * -----------------------------------------------------------------------
 * Renders one day's worth of classes: a header with the day name (plus a
 * "Today" badge when it matches the real current day), and a list of
 * rows pairing each subject with its time slot.
 *
 * `index` is only used to stagger the fade-in animation (see the
 * `--i` CSS variable used by .day-card in index.css).
 * -----------------------------------------------------------------------
 */
export default function DayCard({ label, subjects, isToday, index }) {
  const hasClasses = Array.isArray(subjects) && subjects.length > 0;

  return (
    <div className="day-card" style={{ "--i": index }}>
      <div className="day-card-header">
        <h4>{label}</h4>
        {isToday && <span className="today-badge">Today</span>}
      </div>

      {hasClasses ? (
        <ul className="day-card-list">
          {subjects.map((subject, i) => (
            <li key={`${subject}-${i}`}>
              <span className="time">{TIME_SLOTS[i] || `Period ${i + 1}`}</span>
              <span className="subject">{subject}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="day-card-empty">No classes scheduled</p>
      )}
    </div>
  );
}
