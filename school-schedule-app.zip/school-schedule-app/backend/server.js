/**
 * server.js
 * -----------------------------------------------------------------------
 * This is the backend for the "School Schedule App".
 *
 * What it does:
 *  1. Starts a small Express web server.
 *  2. Reads timetable data from a local JSON file (data/schedules.json) -
 *     there is NO database, the JSON file IS the database.
 *  3. Exposes a couple of simple API endpoints that the React frontend
 *     can call with axios to get the data it needs.
 *
 * If you are new to Express, the short version is:
 *   - `app.get('/some-path', (req, res) => { ... })` defines what happens
 *     when someone visits that URL with a GET request.
 *   - `req` ("request") holds information about the incoming request,
 *     e.g. `req.query` holds the "?course=1&group=A" part of the URL.
 *   - `res` ("response") is what you use to send data back,
 *     e.g. `res.json({ hello: 'world' })`.
 * -----------------------------------------------------------------------
 */

const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 5000;

// Full path to our "database" file.
const SCHEDULES_FILE = path.join(__dirname, "data", "schedules.json");

// -------------------------------------------------------------------------
// Middleware
// -------------------------------------------------------------------------
// CORS lets the frontend (running on a different port, e.g. 5173) make
// requests to this backend (running on port 5000). Without this, the
// browser would block the requests for security reasons.
app.use(cors());

// Lets Express understand JSON request bodies (not strictly required for
// this app since we only use GET requests, but it's good practice to have).
app.use(express.json());

// -------------------------------------------------------------------------
// Helper: load the schedules JSON file from disk
// -------------------------------------------------------------------------
// We re-read the file on every request instead of caching it in memory.
// This is a tiny app, so the performance cost is irrelevant, and it means
// you can edit data/schedules.json, save the file, and immediately see
// the changes the next time you call the API - no server restart needed.
function loadSchedules() {
  const raw = fs.readFileSync(SCHEDULES_FILE, "utf-8");
  return JSON.parse(raw);
}

// -------------------------------------------------------------------------
// Routes
// -------------------------------------------------------------------------

// GET /
// A friendly landing message so visiting the API root in a browser
// doesn't just show "Cannot GET /".
app.get("/", (req, res) => {
  res.json({
    message: "School Schedule API is running.",
    endpoints: {
      "GET /options": "Returns every available course and the groups inside it.",
      "GET /schedule?course=&group=": "Returns the weekly timetable for that course + group.",
    },
  });
});

// GET /options
// The frontend calls this once on page load to fill in the course and
// group dropdowns dynamically, instead of hard-coding "1, 2, 3" / "A, B, C"
// in the React code. This way, if you add a new course or group to the
// JSON file, the dropdowns update automatically.
//
// Example response:
// {
//   "courses": ["1", "2", "3"],
//   "groupsByCourse": { "1": ["A", "B", "C"], "2": ["A", "B", "C"], "3": ["A", "B", "C"] }
// }
app.get("/options", (req, res) => {
  try {
    const schedules = loadSchedules();
    const courses = Object.keys(schedules).sort();

    const groupsByCourse = {};
    courses.forEach((course) => {
      groupsByCourse[course] = Object.keys(schedules[course]).sort();
    });

    res.json({ courses, groupsByCourse });
  } catch (error) {
    console.error("Failed to load options:", error);
    res.status(500).json({ error: "Could not read schedule data." });
  }
});

// GET /schedule?course=1&group=A
// Returns the weekly timetable for one course + group combination.
app.get("/schedule", (req, res) => {
  try {
    // req.query reads values from the URL's query string, e.g. ?course=1&group=A
    const { course, group } = req.query;

    // --- Basic validation -------------------------------------------------
    if (!course || !group) {
      return res.status(400).json({
        error: 'Both "course" and "group" query parameters are required, e.g. /schedule?course=1&group=A',
      });
    }

    const schedules = loadSchedules();
    const normalizedGroup = String(group).toUpperCase();

    const courseData = schedules[course];
    if (!courseData) {
      return res.status(404).json({
        error: `No schedule found for course "${course}".`,
      });
    }

    const groupSchedule = courseData[normalizedGroup];
    if (!groupSchedule) {
      return res.status(404).json({
        error: `No schedule found for course "${course}", group "${normalizedGroup}".`,
      });
    }

    // --- Success ----------------------------------------------------------
    // Shape the response exactly like the project spec describes:
    // { course, group, schedule: { monday: [...], ... } }
    const numericCourse = Number(course);
    res.json({
      course: Number.isNaN(numericCourse) ? course : numericCourse,
      group: normalizedGroup,
      schedule: groupSchedule,
    });
  } catch (error) {
    console.error("Failed to load schedule:", error);
    res.status(500).json({ error: "Could not read schedule data." });
  }
});

// -------------------------------------------------------------------------
// Fallback handlers
// -------------------------------------------------------------------------

// Anything that doesn't match a route above gets a clean 404 JSON response
// instead of Express's default HTML error page.
app.use((req, res) => {
  res.status(404).json({ error: `Route ${req.method} ${req.originalUrl} not found.` });
});

// Catches any unexpected errors thrown inside route handlers above.
app.use((err, req, res, next) => {
  console.error("Unexpected server error:", err);
  res.status(500).json({ error: "Something went wrong on the server." });
});

// -------------------------------------------------------------------------
// Start the server
// -------------------------------------------------------------------------
app.listen(PORT, () => {
  console.log(`✅ School Schedule API running at http://localhost:${PORT}`);
});
